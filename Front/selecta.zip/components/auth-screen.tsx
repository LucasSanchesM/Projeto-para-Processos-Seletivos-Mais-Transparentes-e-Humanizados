"use client"

import { useState } from "react"
import Image from "next/image"
import { ArrowUpRight, Building2, Eye, EyeOff, Quote, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { SelectaLogo } from "@/components/selecta-logo"

type Role = "candidato" | "recrutador"
type Mode = "register" | "login"

const CONTENT: Record<
  Role,
  {
    subtitle: string
    image: string
    imageAlt: string
    quote: string
    author: string
    authorRole: string
    site: string
  }
> = {
  candidato: {
    subtitle: "Cadastre para procurar vagas do mundo todo usando a plataforma",
    image: "/images/candidato.png",
    imageAlt: "Engenheira de software trabalhando concentrada no computador",
    quote: "Essa plataforma tornou a busca por estágio mais humana, transparente e acolhedora.",
    author: "Mirella Viana",
    authorRole: "Engenheira de Software",
    site: "Visitar o site",
  },
  recrutador: {
    subtitle: "Cadastre para encontrar os melhores talentos e montar o seu time",
    image: "/images/recrutador.png",
    imageAlt: "Recrutadora analisando currículos em um escritório moderno",
    quote: "Contratamos mais rápido e com muito mais qualidade desde que começamos a usar a selecta.",
    author: "Rafael Costa",
    authorRole: "Head de Talent Acquisition",
    site: "Visitar o site",
  },
}

export function AuthScreen() {
  const [role, setRole] = useState<Role>("candidato")
  const [mode, setMode] = useState<Mode>("register")
  const [showPassword, setShowPassword] = useState(false)

  // Candidato: formulário à esquerda / imagem à direita.
  // Recrutador: os lados se invertem.
  const formOnLeft = role === "candidato"
  const content = CONTENT[role]

  return (
    <main className="flex min-h-svh items-center justify-center bg-page p-3 sm:p-4">
      <div className="w-full max-w-[1400px] overflow-hidden rounded-2xl bg-card shadow-2xl">
        {/* Container relativo: painéis deslizam para trocar de lado (md+) */}
        <div className="relative flex min-h-[calc(100svh-24px)] flex-col md:block md:h-[calc(100svh-32px)]">
            {/* Painel do formulário */}
            <section
              className={cn(
                "flex flex-col justify-center px-6 py-10 sm:px-10 md:absolute md:top-0 md:h-full md:w-1/2",
                "transition-[left] duration-700 ease-in-out",
              )}
              style={{ left: formOnLeft ? "0%" : "50%" }}
            >
              <div className="mx-auto w-full max-w-sm">
                <SelectaLogo className="mb-8" />

                {/* Seletor candidato / recrutador */}
                <div
                  className="mb-6 grid grid-cols-2 gap-1 rounded-lg bg-accent p-1"
                  role="tablist"
                  aria-label="Selecione o tipo de conta"
                >
                  <RoleTab
                    active={role === "candidato"}
                    onClick={() => setRole("candidato")}
                    icon={<User className="h-4 w-4" />}
                    label="Candidato"
                  />
                  <RoleTab
                    active={role === "recrutador"}
                    onClick={() => setRole("recrutador")}
                    icon={<Building2 className="h-4 w-4" />}
                    label="Recrutador"
                  />
                </div>

                <h1 className="text-2xl font-bold tracking-tight text-foreground">
                  {mode === "register" ? "Crie sua conta" : "Bem-vindo de volta"}
                </h1>
                <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">
                  {mode === "register"
                    ? content.subtitle
                    : `Entre na sua conta de ${role} para continuar`}
                </p>

                <form className="mt-6 space-y-4" onSubmit={(e) => e.preventDefault()}>
                  {mode === "register" && (
                    <Field label="Nome completo" htmlFor="name">
                      <input
                        id="name"
                        type="text"
                        placeholder="Como deseja ser chamado?"
                        className="auth-input"
                      />
                    </Field>
                  )}

                  <Field label="Seu email" htmlFor="email">
                    <input
                      id="email"
                      type="email"
                      placeholder="gabriel.dev@gmail.com"
                      className="auth-input"
                    />
                  </Field>

                  {mode === "register" ? (
                    <div className="grid grid-cols-2 gap-3">
                      <Field label="Senha" htmlFor="password">
                        <PasswordInput
                          id="password"
                          show={showPassword}
                          onToggle={() => setShowPassword((v) => !v)}
                        />
                      </Field>
                      <Field label="Confirme a senha" htmlFor="confirm">
                        <PasswordInput id="confirm" show={showPassword} onToggle={() => setShowPassword((v) => !v)} />
                      </Field>
                    </div>
                  ) : (
                    <Field label="Senha" htmlFor="password">
                      <PasswordInput
                        id="password"
                        show={showPassword}
                        onToggle={() => setShowPassword((v) => !v)}
                      />
                    </Field>
                  )}

                  {mode === "register" ? (
                    <p className="text-xs leading-relaxed text-muted-foreground">
                      Ao criar uma conta, você concorda com nossos{" "}
                      <a href="#" className="text-foreground underline underline-offset-2">
                        Termos de Serviço
                      </a>{" "}
                      e{" "}
                      <a href="#" className="text-foreground underline underline-offset-2">
                        Política de Privacidade
                      </a>
                      .
                    </p>
                  ) : (
                    <div className="flex justify-end">
                      <a href="#" className="text-xs font-medium text-primary hover:underline">
                        Esqueceu a senha?
                      </a>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full rounded-lg bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:opacity-90"
                  >
                    {mode === "register"
                      ? role === "candidato"
                        ? "Criar conta"
                        : "Criar conta de recrutador"
                      : "Entrar"}
                  </button>
                </form>

                <p className="mt-6 text-center text-sm text-muted-foreground">
                  {mode === "register" ? (
                    <>
                      Já tem uma conta?{" "}
                      <button
                        type="button"
                        onClick={() => setMode("login")}
                        className="font-semibold text-primary hover:underline"
                      >
                        Faça login agora
                      </button>
                    </>
                  ) : (
                    <>
                      Ainda não tem conta?{" "}
                      <button
                        type="button"
                        onClick={() => setMode("register")}
                        className="font-semibold text-primary hover:underline"
                      >
                        Cadastre-se
                      </button>
                    </>
                  )}
                </p>
              </div>
            </section>

            {/* Painel da imagem / depoimento */}
            <section
              className={cn(
                "relative min-h-[280px] overflow-hidden md:absolute md:top-0 md:h-full md:w-1/2",
                "transition-[left] duration-700 ease-in-out",
              )}
              style={{ left: formOnLeft ? "50%" : "0%" }}
            >
              <div className="absolute inset-0 p-2">
                <div className="relative h-full w-full overflow-hidden rounded-xl">
                  <Image
                    key={content.image}
                    src={content.image || "/placeholder.svg"}
                    alt={content.imageAlt}
                    fill
                    priority
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30" />

                  {/* Ícone de citação */}
                  <div className="absolute left-6 top-6 flex h-9 w-9 items-center justify-center rounded-lg bg-white/90 text-black">
                    <Quote className="h-4 w-4 fill-current" />
                  </div>

                  {/* Conteúdo inferior */}
                  <div className="absolute inset-x-6 bottom-6 text-white">
                    <a
                      href="#"
                      className="mb-5 inline-flex items-center gap-1 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur-sm transition-colors hover:bg-white/20"
                    >
                      {content.site}
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </a>
                    <blockquote className="text-pretty text-lg font-semibold leading-snug">
                      &ldquo;{content.quote}&rdquo;
                    </blockquote>
                    <div className="mt-4">
                      <p className="text-sm font-semibold">{content.author}</p>
                      <p className="text-xs text-white/70">{content.authorRole}</p>
                    </div>
                    <div className="mt-5 flex gap-2">
                      {[0, 1, 2, 3].map((i) => (
                        <span
                          key={i}
                          className={cn(
                            "h-1 flex-1 rounded-full transition-colors",
                            i === (role === "candidato" ? 0 : 1) ? "bg-white" : "bg-white/30",
                          )}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </section>
        </div>
      </div>
    </main>
  )
}

function RoleTab({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean
  onClick: () => void
  icon: React.ReactNode
  label: string
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={cn(
        "flex items-center justify-center gap-2 rounded-md py-2 text-sm font-medium transition-all",
        active ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
      )}
    >
      {icon}
      {label}
    </button>
  )
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string
  htmlFor: string
  children: React.ReactNode
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={htmlFor} className="block text-sm font-semibold text-foreground">
        {label}
      </label>
      {children}
    </div>
  )
}

function PasswordInput({
  id,
  show,
  onToggle,
}: {
  id: string
  show: boolean
  onToggle: () => void
}) {
  return (
    <div className="relative">
      <input
        id={id}
        type={show ? "text" : "password"}
        placeholder="••••••••"
        className="auth-input pr-10"
      />
      <button
        type="button"
        onClick={onToggle}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        aria-label={show ? "Ocultar senha" : "Mostrar senha"}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  )
}
