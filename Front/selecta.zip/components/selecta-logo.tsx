export function SelectaLogo({ className }: { className?: string }) {
  return (
    <div className={className}>
      <span className="flex items-center gap-2">
        <span className="relative inline-flex h-6 w-6" aria-hidden="true">
          <span className="absolute left-0 top-0 h-6 w-4 rounded-full bg-[oklch(0.72_0.18_45)]" />
          <span className="absolute right-0 top-0 h-6 w-4 rounded-full bg-[oklch(0.7_0.13_180)] mix-blend-multiply" />
        </span>
        <span className="text-lg font-semibold tracking-tight text-foreground">selecta</span>
      </span>
    </div>
  )
}
